package com.example.util

import android.content.ActivityNotFoundException
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import com.example.data.model.Product
import com.example.data.model.SaleTransaction
import com.example.data.model.StockCard
import com.example.data.model.StoreSettings
import com.example.ui.components.formatRupiah
import com.example.ui.components.formatTimestamp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class DownloadedFile(
    val fileName: String,
    val mimeType: String,
    val uri: Uri,
    val locationLabel: String
)

object StoreFileExporter {

    private val idLocale = Locale.Builder().setLanguage("id").setRegion("ID").build()

    private fun timestampSlug(): String =
        SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    private fun nowDisplay(): String =
        SimpleDateFormat("dd MMM yyyy, HH:mm", idLocale).format(Date())

    private suspend fun saveToDownloads(
        context: Context,
        fileName: String,
        mimeType: String,
        writer: (OutputStream) -> Unit
    ): Result<DownloadedFile> = withContext(Dispatchers.IO) {
        runCatching {
            val resolver = context.contentResolver
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                    put(MediaStore.Downloads.MIME_TYPE, mimeType)
                    put(MediaStore.Downloads.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/TokoKita")
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: error("Gagal membuat file di folder Download.")
                try {
                    resolver.openOutputStream(uri)?.use { out ->
                        writer(out)
                        out.flush()
                    } ?: error("Gagal membuka aliran tulis file.")
                    values.clear()
                    values.put(MediaStore.Downloads.IS_PENDING, 0)
                    resolver.update(uri, values, null, null)
                } catch (t: Throwable) {
                    runCatching { resolver.delete(uri, null, null) }
                    throw t
                }
                DownloadedFile(
                    fileName = fileName,
                    mimeType = mimeType,
                    uri = uri,
                    locationLabel = "Folder Download/TokoKita/$fileName"
                )
            } else {
                val dir = File(
                    context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: context.filesDir,
                    "TokoKita"
                ).apply { mkdirs() }
                val targetFile = File(dir, fileName)
                FileOutputStream(targetFile).use { out ->
                    writer(out)
                    out.flush()
                }
                val uri = FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    targetFile
                )
                DownloadedFile(
                    fileName = fileName,
                    mimeType = mimeType,
                    uri = uri,
                    locationLabel = "Folder Download/TokoKita/$fileName"
                )
            }
        }
    }

    fun openDownloadedFile(context: Context, file: DownloadedFile) {
        val viewIntent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(file.uri, file.mimeType)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            context.startActivity(viewIntent)
        } catch (_: ActivityNotFoundException) {
            shareDownloadedFile(context, file)
        }
    }

    fun shareDownloadedFile(context: Context, file: DownloadedFile) {
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = file.mimeType
            putExtra(Intent.EXTRA_STREAM, file.uri)
            putExtra(Intent.EXTRA_SUBJECT, file.fileName)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(shareIntent, "Bagikan / Buka ${file.fileName}").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(chooser)
    }

    private fun csvCell(raw: Any?): String {
        val text = raw?.toString().orEmpty()
        val escaped = text.replace("\"", "\"\"")
        return "\"$escaped\""
    }

    private fun writeCsvBom(out: OutputStream, rows: List<List<Any?>>) {
        out.write(byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()))
        val sb = StringBuilder()
        rows.forEach { row ->
            sb.append(row.joinToString(",") { csvCell(it) }).append("\r\n")
        }
        out.write(sb.toString().toByteArray(Charsets.UTF_8))
    }

    suspend fun exportProductsCsv(
        context: Context,
        products: List<Product>
    ): Result<DownloadedFile> {
        val fileName = "Daftar_Barang_${timestampSlug()}.csv"
        val rows = buildList {
            add(
                listOf(
                    "SKU",
                    "Nama Barang",
                    "Kategori",
                    "Merek",
                    "Satuan Dasar",
                    "Stok Dasar",
                    "Min Stok",
                    "Harga Pokok (HPP)",
                    "Satuan Jual",
                    "Qty Isi",
                    "Min Beli",
                    "Harga Default",
                    "Harga Grosir",
                    "Harga Member VIP"
                )
            )
            products.forEach { p ->
                val units = p.priceUnits.ifEmpty { listOf(p.defaultUnit()) }
                units.forEach { u ->
                    add(
                        listOf(
                            p.sku,
                            p.name,
                            p.categoryName,
                            p.brandName,
                            p.baseUnitName,
                            p.stockBase,
                            p.minStockAlert,
                            p.costPrice,
                            u.unitName,
                            u.qtyContent,
                            u.minBuy,
                            u.priceDefault,
                            u.priceGrosir,
                            u.priceMemberVip
                        )
                    )
                }
            }
        }
        return saveToDownloads(context, fileName, "text/csv") { out ->
            writeCsvBom(out, rows)
        }
    }

    suspend fun exportProductsPdf(
        context: Context,
        products: List<Product>,
        settings: StoreSettings
    ): Result<DownloadedFile> {
        val fileName = "Katalog_Barang_${timestampSlug()}.pdf"
        return saveToDownloads(context, fileName, "application/pdf") { out ->
            val doc = PdfDocument()
            val pageWidth = 595
            val pageHeight = 842
            val margin = 36f

            val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#0F2444")
                textSize = 18f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            val subPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#475569")
                textSize = 10f
            }
            val headerBgPaint = Paint().apply { color = Color.parseColor("#E2E8F0") }
            val headerTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#0F172A")
                textSize = 9.5f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#0F172A")
                textSize = 9.5f
            }
            val boldBodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#0F172A")
                textSize = 9.5f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            val linePaint = Paint().apply {
                color = Color.parseColor("#CBD5E1")
                strokeWidth = 1f
            }

            var pageNumber = 1
            var page = doc.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create())
            var canvas = page.canvas
            var y = 46f

            fun drawHeader() {
                canvas.drawText(settings.storeName.ifEmpty { "TokoKita" }, margin, y, titlePaint)
                y += 16f
                canvas.drawText(
                    "Katalog Barang & Daftar Harga Multi-Satuan · Dicetak ${nowDisplay()}",
                    margin,
                    y,
                    subPaint
                )
                y += 14f
                canvas.drawText(
                    "Total SKU: ${products.size} · Total Unit Dasar: ${products.sumOf { it.stockBase }}",
                    margin,
                    y,
                    subPaint
                )
                y += 14f
                canvas.drawRect(margin, y, pageWidth - margin, y + 20f, headerBgPaint)
                canvas.drawText("SKU / Nama Barang", margin + 6f, y + 13f, headerTextPaint)
                canvas.drawText("Stok", margin + 215f, y + 13f, headerTextPaint)
                canvas.drawText("HPP", margin + 275f, y + 13f, headerTextPaint)
                canvas.drawText("Harga Jual (Default / Grosir / VIP)", margin + 345f, y + 13f, headerTextPaint)
                y += 28f
            }

            drawHeader()

            products.forEach { product ->
                val units = product.priceUnits.ifEmpty { listOf(product.defaultUnit()) }
                val blockHeight = 16f + (units.size * 13f) + 10f
                if (y + blockHeight > pageHeight - 40f) {
                    doc.finishPage(page)
                    pageNumber++
                    page = doc.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create())
                    canvas = page.canvas
                    y = 46f
                    drawHeader()
                }
                canvas.drawText(
                    "${product.sku} · ${product.name.take(30)}",
                    margin + 4f,
                    y,
                    boldBodyPaint
                )
                canvas.drawText("${product.stockBase} ${product.baseUnitName}", margin + 215f, y, bodyPaint)
                canvas.drawText(formatRupiah(product.costPrice), margin + 275f, y, bodyPaint)
                y += 14f
                units.forEach { unit ->
                    canvas.drawText(
                        "• ${unit.unitName} (Isi ${unit.qtyContent}): Def ${formatRupiah(unit.priceDefault)} | Grs ${formatRupiah(unit.priceGrosir)} | VIP ${formatRupiah(unit.priceMemberVip)}",
                        margin + 12f,
                        y,
                        subPaint
                    )
                    y += 13f
                }
                canvas.drawLine(margin, y, pageWidth - margin, y, linePaint)
                y += 10f
            }

            doc.finishPage(page)
            doc.writeTo(out)
            doc.close()
        }
    }

    suspend fun exportTransactionsCsv(
        context: Context,
        transactions: List<SaleTransaction>
    ): Result<DownloadedFile> {
        val fileName = "Laporan_Penjualan_${timestampSlug()}.csv"
        val rows = buildList {
            add(
                listOf(
                    "No Struk",
                    "Tanggal",
                    "Pelanggan",
                    "Tipe Harga",
                    "Metode Bayar",
                    "Jumlah Item",
                    "Total Belanja",
                    "Total Modal (HPP)",
                    "Laba Kotor",
                    "Dibayar",
                    "Kembalian",
                    "Detail Barang"
                )
            )
            transactions.forEach { trx ->
                val detail = trx.items.joinToString("; ") {
                    "${it.productName} (${it.qty} ${it.unitName} @ ${it.unitPrice})"
                }
                add(
                    listOf(
                        trx.receiptNumber,
                        formatTimestamp(trx.createdAt),
                        trx.customerName,
                        trx.tier().badgeText,
                        trx.payment().label,
                        trx.itemCount,
                        trx.totalAmount,
                        trx.totalCost,
                        trx.totalProfit,
                        trx.cashPaid,
                        trx.changeAmount,
                        detail
                    )
                )
            }
        }
        return saveToDownloads(context, fileName, "text/csv") { out ->
            writeCsvBom(out, rows)
        }
    }

    suspend fun exportTransactionsPdf(
        context: Context,
        transactions: List<SaleTransaction>,
        settings: StoreSettings
    ): Result<DownloadedFile> {
        val fileName = "Laporan_Penjualan_${timestampSlug()}.pdf"
        return saveToDownloads(context, fileName, "application/pdf") { out ->
            val doc = PdfDocument()
            val pageWidth = 595
            val pageHeight = 842
            val margin = 36f

            val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#0F2444")
                textSize = 18f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            val subPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#475569")
                textSize = 10f
            }
            val summaryBg = Paint().apply { color = Color.parseColor("#EFF6FF") }
            val headerBg = Paint().apply { color = Color.parseColor("#E2E8F0") }
            val headerText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#0F172A")
                textSize = 9.5f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#0F172A")
                textSize = 9.5f
            }
            val profitPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#059669")
                textSize = 9.5f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            val linePaint = Paint().apply {
                color = Color.parseColor("#CBD5E1")
                strokeWidth = 1f
            }

            val totalOmzet = transactions.sumOf { it.totalAmount }
            val totalLaba = transactions.sumOf { it.totalProfit }

            var pageNum = 1
            var page = doc.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNum).create())
            var canvas = page.canvas
            var y = 46f

            fun drawTop(includeSummary: Boolean) {
                canvas.drawText(settings.storeName.ifEmpty { "TokoKita" }, margin, y, titlePaint)
                y += 16f
                canvas.drawText("Laporan Riwayat Penjualan · Dicetak ${nowDisplay()}", margin, y, subPaint)
                y += 12f
                if (includeSummary) {
                    canvas.drawRect(margin, y, pageWidth - margin, y + 36f, summaryBg)
                    canvas.drawText(
                        "Total Transaksi: ${transactions.size} struk",
                        margin + 10f,
                        y + 14f,
                        headerText
                    )
                    canvas.drawText(
                        "Total Omzet: ${formatRupiah(totalOmzet)}   |   Total Laba: ${formatRupiah(totalLaba)}",
                        margin + 10f,
                        y + 28f,
                        profitPaint
                    )
                    y += 46f
                } else {
                    y += 8f
                }
                canvas.drawRect(margin, y, pageWidth - margin, y + 20f, headerBg)
                canvas.drawText("No Struk / Tanggal", margin + 6f, y + 13f, headerText)
                canvas.drawText("Pelanggan", margin + 170f, y + 13f, headerText)
                canvas.drawText("Bayar", margin + 305f, y + 13f, headerText)
                canvas.drawText("Total", margin + 375f, y + 13f, headerText)
                canvas.drawText("Laba", margin + 455f, y + 13f, headerText)
                y += 28f
            }

            drawTop(includeSummary = true)

            transactions.forEach { trx ->
                if (y + 34f > pageHeight - 40f) {
                    doc.finishPage(page)
                    pageNum++
                    page = doc.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNum).create())
                    canvas = page.canvas
                    y = 46f
                    drawTop(includeSummary = false)
                }
                canvas.drawText(trx.receiptNumber, margin + 4f, y, headerText)
                canvas.drawText("${trx.customerName.take(18)} (${trx.tier().badgeText})", margin + 170f, y, bodyPaint)
                canvas.drawText(trx.payment().label, margin + 305f, y, bodyPaint)
                canvas.drawText(formatRupiah(trx.totalAmount), margin + 375f, y, bodyPaint)
                canvas.drawText(formatRupiah(trx.totalProfit), margin + 455f, y, profitPaint)
                y += 13f
                canvas.drawText(
                    "${formatTimestamp(trx.createdAt)} · ${trx.itemCount} item",
                    margin + 4f,
                    y,
                    subPaint
                )
                y += 8f
                canvas.drawLine(margin, y, pageWidth - margin, y, linePaint)
                y += 11f
            }

            doc.finishPage(page)
            doc.writeTo(out)
            doc.close()
        }
    }

    suspend fun exportStockCardsCsv(
        context: Context,
        stockCards: List<StockCard>
    ): Result<DownloadedFile> {
        val fileName = "Kartu_Stok_${timestampSlug()}.csv"
        val rows = buildList {
            add(
                listOf(
                    "Tanggal",
                    "SKU",
                    "Nama Barang",
                    "Jenis Mutasi",
                    "Perubahan Qty",
                    "Stok Sebelum",
                    "Stok Sesudah",
                    "Satuan",
                    "Catatan"
                )
            )
            stockCards.forEach { card ->
                add(
                    listOf(
                        formatTimestamp(card.createdAt),
                        card.sku,
                        card.productName,
                        card.movement().label,
                        card.qtyChange,
                        card.stockBefore,
                        card.stockAfter,
                        card.unitSummary,
                        card.note
                    )
                )
            }
        }
        return saveToDownloads(context, fileName, "text/csv") { out ->
            writeCsvBom(out, rows)
        }
    }

    suspend fun exportStockCardsPdf(
        context: Context,
        stockCards: List<StockCard>,
        settings: StoreSettings
    ): Result<DownloadedFile> {
        val fileName = "Kartu_Stok_${timestampSlug()}.pdf"
        return saveToDownloads(context, fileName, "application/pdf") { out ->
            val doc = PdfDocument()
            val pageWidth = 595
            val pageHeight = 842
            val margin = 36f

            val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#0F2444")
                textSize = 18f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            val subPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#475569")
                textSize = 10f
            }
            val headerBg = Paint().apply { color = Color.parseColor("#E2E8F0") }
            val headerText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#0F172A")
                textSize = 9.5f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#0F172A")
                textSize = 9.5f
            }
            val linePaint = Paint().apply {
                color = Color.parseColor("#CBD5E1")
                strokeWidth = 1f
            }

            var pageNum = 1
            var page = doc.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNum).create())
            var canvas = page.canvas
            var y = 46f

            fun drawTop() {
                canvas.drawText(settings.storeName.ifEmpty { "TokoKita" }, margin, y, titlePaint)
                y += 16f
                canvas.drawText("Kartu Stok Barang · ${stockCards.size} mutasi · Dicetak ${nowDisplay()}", margin, y, subPaint)
                y += 14f
                canvas.drawRect(margin, y, pageWidth - margin, y + 20f, headerBg)
                canvas.drawText("Barang / SKU", margin + 6f, y + 13f, headerText)
                canvas.drawText("Mutasi", margin + 210f, y + 13f, headerText)
                canvas.drawText("Delta", margin + 300f, y + 13f, headerText)
                canvas.drawText("Stok (Sblm -> Ssdh)", margin + 370f, y + 13f, headerText)
                y += 28f
            }

            drawTop()

            stockCards.forEach { card ->
                if (y + 34f > pageHeight - 40f) {
                    doc.finishPage(page)
                    pageNum++
                    page = doc.startPage(PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNum).create())
                    canvas = page.canvas
                    y = 46f
                    drawTop()
                }
                val delta = if (card.qtyChange >= 0) "+${card.qtyChange}" else "${card.qtyChange}"
                canvas.drawText("${card.productName.take(28)} (${card.sku})", margin + 4f, y, headerText)
                canvas.drawText(card.movement().label, margin + 210f, y, bodyPaint)
                canvas.drawText(delta, margin + 300f, y, headerText)
                canvas.drawText("${card.stockBefore} -> ${card.stockAfter}", margin + 370f, y, bodyPaint)
                y += 13f
                canvas.drawText(
                    "${card.note.take(45)} · ${card.unitSummary} · ${formatTimestamp(card.createdAt)}",
                    margin + 4f,
                    y,
                    subPaint
                )
                y += 8f
                canvas.drawLine(margin, y, pageWidth - margin, y, linePaint)
                y += 11f
            }

            doc.finishPage(page)
            doc.writeTo(out)
            doc.close()
        }
    }

    suspend fun exportReceiptPdf(
        context: Context,
        transaction: SaleTransaction,
        settings: StoreSettings
    ): Result<DownloadedFile> {
        val safeNo = transaction.receiptNumber.replace(Regex("[^a-zA-Z0-9_-]"), "_")
        val fileName = "Struk_${safeNo}_${timestampSlug()}.pdf"
        return saveToDownloads(context, fileName, "application/pdf") { out ->
            val pageWidth = 340
            val estimatedHeight = (300 + transaction.items.size * 34).coerceAtLeast(380)
            val doc = PdfDocument()
            val page = doc.startPage(PdfDocument.PageInfo.Builder(pageWidth, estimatedHeight, 1).create())
            val canvas = page.canvas
            val margin = 22f

            val centerBold = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#0F172A")
                textSize = 15f
                textAlign = Paint.Align.CENTER
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            val centerSub = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#475569")
                textSize = 9.5f
                textAlign = Paint.Align.CENTER
            }
            val leftText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#0F172A")
                textSize = 10f
            }
            val leftBold = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#0F172A")
                textSize = 10.5f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            val rightText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#0F172A")
                textSize = 10f
                textAlign = Paint.Align.RIGHT
            }
            val rightBold = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#0F172A")
                textSize = 11f
                textAlign = Paint.Align.RIGHT
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            val linePaint = Paint().apply {
                color = Color.parseColor("#94A3B8")
                strokeWidth = 1f
            }

            var y = 32f
            canvas.drawText(settings.storeName.ifEmpty { "TokoKita" }, pageWidth / 2f, y, centerBold)
            y += 14f
            if (settings.storeAddress.isNotBlank()) {
                canvas.drawText(settings.storeAddress.take(42), pageWidth / 2f, y, centerSub)
                y += 12f
            }
            if (settings.storePhone.isNotBlank()) {
                canvas.drawText("Telp: ${settings.storePhone}", pageWidth / 2f, y, centerSub)
                y += 12f
            }
            y += 4f
            canvas.drawLine(margin, y, pageWidth - margin, y, linePaint)
            y += 16f

            canvas.drawText(transaction.receiptNumber, margin, y, leftBold)
            canvas.drawText(transaction.tier().badgeText, pageWidth - margin, y, rightBold)
            y += 14f
            canvas.drawText("${formatTimestamp(transaction.createdAt)} · ${transaction.customerName}", margin, y, leftText)
            y += 10f
            canvas.drawLine(margin, y, pageWidth - margin, y, linePaint)
            y += 16f

            transaction.items.forEach { item ->
                canvas.drawText(item.productName.take(34), margin, y, leftBold)
                y += 13f
                canvas.drawText(
                    "${item.qty} ${item.unitName} × ${formatRupiah(item.unitPrice)}",
                    margin,
                    y,
                    leftText
                )
                canvas.drawText(formatRupiah(item.subtotal), pageWidth - margin, y, rightText)
                y += 16f
            }

            canvas.drawLine(margin, y, pageWidth - margin, y, linePaint)
            y += 16f

            canvas.drawText("Total Belanja", margin, y, leftBold)
            canvas.drawText(formatRupiah(transaction.totalAmount), pageWidth - margin, y, rightBold)
            y += 15f
            canvas.drawText("Bayar (${transaction.payment().label})", margin, y, leftText)
            canvas.drawText(formatRupiah(transaction.cashPaid), pageWidth - margin, y, rightText)
            y += 15f
            canvas.drawText("Kembalian", margin, y, leftText)
            canvas.drawText(formatRupiah(transaction.changeAmount), pageWidth - margin, y, rightText)
            y += 18f

            if (settings.receiptFooter.isNotBlank()) {
                canvas.drawLine(margin, y, pageWidth - margin, y, linePaint)
                y += 16f
                canvas.drawText(settings.receiptFooter.take(46), pageWidth / 2f, y, centerSub)
            }

            doc.finishPage(page)
            doc.writeTo(out)
            doc.close()
        }
    }

    private fun renderBarcodeLabelBitmap(product: Product): Bitmap {
        val width = 800
        val height = 430
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.WHITE)

        val borderPaint = Paint().apply {
            color = Color.parseColor("#CBD5E1")
            style = Paint.Style.STROKE
            strokeWidth = 4f
        }
        canvas.drawRect(12f, 12f, width - 12f, height - 12f, borderPaint)

        val namePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#0F172A")
            textSize = 32f
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val pricePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#059669")
            textSize = 36f
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val skuPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#334155")
            textSize = 26f
            textAlign = Paint.Align.CENTER
            typeface = Typeface.MONOSPACE
        }

        canvas.drawText(product.name.take(32), width / 2f, 76f, namePaint)
        canvas.drawText(
            "${formatRupiah(product.displayDefaultPrice())} / ${product.defaultUnit().unitName}",
            width / 2f,
            132f,
            pricePaint
        )

        val cleanCode = product.sku.ifEmpty { "00000000" }
        val bits = buildList {
            add(true); add(false); add(true)
            cleanCode.forEach { ch ->
                val v = ch.code
                for (b in 0 until 6) {
                    add(((v shr b) and 1) == 1)
                    if (b % 2 == 1) add((v + b) % 3 == 0)
                }
            }
            add(true); add(false); add(true)
        }

        val leftPad = 70f
        val barAreaWidth = width - 140f
        val barWidth = barAreaWidth / bits.size.coerceAtLeast(1)
        val barPaint = Paint().apply { color = Color.parseColor("#0F172A") }
        bits.forEachIndexed { idx, isBlack ->
            if (isBlack) {
                val x = leftPad + idx * barWidth
                canvas.drawRect(x, 165f, x + barWidth.coerceAtLeast(3f), 325f, barPaint)
            }
        }

        canvas.drawText(cleanCode, width / 2f, 375f, skuPaint)
        return bitmap
    }

    suspend fun exportBarcodePng(
        context: Context,
        product: Product
    ): Result<DownloadedFile> {
        val safeSku = product.sku.ifEmpty { "SKU" }.replace(Regex("[^a-zA-Z0-9_-]"), "_")
        val fileName = "Barcode_${safeSku}_${timestampSlug()}.png"
        val bitmap = renderBarcodeLabelBitmap(product)
        return try {
            saveToDownloads(context, fileName, "image/png") { out ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
            }
        } finally {
            bitmap.recycle()
        }
    }

    suspend fun exportBarcodePdf(
        context: Context,
        product: Product
    ): Result<DownloadedFile> {
        val safeSku = product.sku.ifEmpty { "SKU" }.replace(Regex("[^a-zA-Z0-9_-]"), "_")
        val fileName = "Barcode_${safeSku}_${timestampSlug()}.pdf"
        val bitmap = renderBarcodeLabelBitmap(product)
        return try {
            saveToDownloads(context, fileName, "application/pdf") { out ->
                val doc = PdfDocument()
                val page = doc.startPage(PdfDocument.PageInfo.Builder(420, 240, 1).create())
                page.canvas.drawBitmap(
                    bitmap,
                    null,
                    android.graphics.Rect(10, 10, 410, 230),
                    null
                )
                doc.finishPage(page)
                doc.writeTo(out)
                doc.close()
            }
        } finally {
            bitmap.recycle()
        }
    }
}
